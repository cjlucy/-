//
//  CinemaCell.m
//  项目一01
//
//  Created by apple on 15/8/12.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "CinemaCell.h"

@implementation CinemaCell

- (void)awakeFromNib {
    // Initialization code
}



- (void)setCinema:(Cinema *)cinema
{
    _cinema = cinema;
    
    _cinemaName.text = _cinema.name;
    
    _address.text = _cinema.address;
    
    _rating.text = _cinema.grade;
    
//    价格
    if ([_cinema.lowPrice isKindOfClass:[NSNull class]] )
    {
        _price.text = @" ";
    }
    else
    {
        _price.text = _cinema.lowPrice;
    }
    
    if ([_cinema.distance isKindOfClass:[NSNull class]])
    {
         _distance.text = [NSString stringWithFormat:@"0 km"];
    }
    else
    {
        _distance.text = [NSString stringWithFormat:@"%@ km",_cinema.distance];
    }
    
    
//    座位
    if ([_cinema.isSeatSupport isEqualToString:@"1"])
    {
        _seatImage.image = [UIImage imageNamed:@"cinemaSeatMark@2x.png"];
    }
    
//    优惠券
    if ([_cinema.isCouponSupport isEqualToString:@"1"])
    {
        _couponImage.image = [UIImage imageNamed:@"cinemaCouponMark@2x.png"];
    }
    
//    团购
    if ([_cinema.isGroupBuySupport isEqualToString:@"1"])
    {
        _groupImage.image = [UIImage imageNamed:@"cinemaGrouponMark@2x.png"];
    }
    
}









- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
