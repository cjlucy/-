//
//  CinemaViewController.m
//  项目一01
//
//  Created by apple on 15/8/3.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "CinemaViewController.h"

@interface CinemaViewController ()

@end

@implementation CinemaViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = @"影院";
    
    _cinemaTableView.dataSource = self;
    _cinemaTableView.delegate = self;
    _cinemaTableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main@2x"]];
    



    
    [self _loadDatas];
    
    
}

- (void)_loadDatas
{    
    
    NSString *filepath = [[NSBundle mainBundle] pathForResource:@"cinema_list" ofType:@"json"];
    //    2.读取文件
    NSData *data = [NSData dataWithContentsOfFile:filepath];
    //    3.解析文件
    NSError *error = [[NSError alloc] init];
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data
                                                        options:NSJSONReadingMutableLeaves
                                                       error:&error];
    
    _cinemaData = [[NSMutableArray alloc] init];
    for (NSDictionary *d in dic[@"cinemaList"])
    {
        Cinema *cinema = [[Cinema alloc] initWithDictionary:d];
        
        [_cinemaData addObject:cinema];
    }
    
 
    NSString *filepath1 = [[NSBundle mainBundle] pathForResource:@"district_list" ofType:@"json"];
    //    2.读取文件
    NSData *data1 = [NSData dataWithContentsOfFile:filepath1];
    //    3.解析文件
     NSDictionary *dic1 = [NSJSONSerialization JSONObjectWithData:data1
                                                        options:NSJSONReadingMutableLeaves
                                                          error:&error];
    _districtData = [[NSMutableArray alloc] init];
    _districtData = dic1[@"districtList"];
  
    
    
    
    _newCinemaData = [[NSMutableArray alloc] init];
    
    
    for (int i = 0; i < _districtData.count; i ++)
    {
        NSString *str = _districtData[i][@"id"];
        
        NSMutableArray *array = [[NSMutableArray alloc] init];
        
        for (int j = 0; j < _cinemaData.count; j++)
        {
            Cinema *cinema = _cinemaData[j];
            NSString *str1 = cinema.districtId;
            if ([str isEqualToString:str1])
            {
                [array addObject:cinema];
                
            }
            
        }
        [_newCinemaData addObject:array];
    }
    

}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   
    
    if (_isShow[section])
    {
         NSDictionary *dic = [_newCinemaData objectAtIndex:section];
        return dic.count;
    }
    else
    {
        return 0;
    }
    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    CinemaCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if (cell == nil)
    {
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"CinemaCell"
                                                       owner:nil
                                                     options:nil];
        cell = [array lastObject];
  
    }

    cell.cinema = _newCinemaData[indexPath.section][indexPath.row];

    
    return cell;
}

//单元格宽度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

//返回组数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _districtData.count;
}

//组头视图高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 42;
}




//组头视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"hotMovieBottomImage@2x"] forState:UIControlStateNormal];

    button.frame =CGRectMake(0, 0, kScreenHeight, 42);

    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    NSDictionary *dic = _districtData[section];
    NSString *title = dic[@"name"];
    button.tag = section;
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, 100, 35)];
    label.text = title;
    [button addSubview:label];
    [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    return button;
    
}

- (void)buttonAction:(UIButton *)button
{
    NSInteger section = button.tag;
    _isShow[section] = !_isShow[section];
    NSIndexSet *set = [NSIndexSet indexSetWithIndex:section];
    
    
    [_cinemaTableView reloadSections:set
              withRowAnimation:UITableViewRowAnimationFade];
    
    
}








- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
