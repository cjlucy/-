//
//  TabBarButton.m
//  项目一01
//
//  Created by apple on 15/8/3.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "TabBarButton.h"

@implementation TabBarButton



- (id)initWithFrame:(CGRect)frame
            imageName:(NSString *)image
                title:(NSString *)title
{
    self = [super init];
    if (self)
    {
        frame.size.height = 49;
        frame.origin.y = 0;
        self.frame = frame;
        
        [self _createSubView];
        
        _imageView.image = [UIImage imageNamed:image];
        _titleLabel.text = title;

    }

    return self;

}

- (void)_createSubView
{
    _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 30, 20)];
    _imageView.center = CGPointMake(self.frame.size.width / 2, self.frame.size.height / 2 - 5);
//    图片拉伸
    _imageView.contentMode = UIViewContentModeScaleAspectFit;
    [self addSubview:_imageView];
    
 
    
//    创建label
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 30, 10)];
    _titleLabel.font = [UIFont systemFontOfSize:10];
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.center = CGPointMake(self.frame.size.width / 2, self.frame.size.height / 2);
    _titleLabel.top = _imageView.bottom + 3;
    
    [self addSubview:_titleLabel];
    
}






@end
