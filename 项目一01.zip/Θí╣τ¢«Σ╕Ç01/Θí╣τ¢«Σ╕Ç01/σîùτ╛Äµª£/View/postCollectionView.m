
//  postCollectionView.m
//  项目一01
//
//  Created by apple on 15/8/10.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "postCollectionView.h"

@implementation postCollectionView



#pragma mark - self.datasouse

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    PostCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"postCell" forIndexPath:indexPath];
    
    cell.movie = self.movieDatas[indexPath.row];
    return cell;
}



// 点击单元格 滑动／翻转
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
//    判断点击的是哪个单元格
//    1.根据偏移量 计算当前显示在最中间的单元格
    NSInteger index = collectionView.contentOffset.x / (collectionView.width * 0.6 + 10);
    
//    2.和被点击中的单元格 indexPath 做比较
    if (index == indexPath.item)
    {
//        点击的是正中间的单元格 做翻转
        PostCollectionViewCell *cell = (PostCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
        [cell flipCell];
        
    }
    else
    {
//        点击的是两边的单元格  滑动到中间
        [collectionView scrollToItemAtIndexPath:indexPath
                               atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
     
       self.currentIndex = indexPath.item;
    }
    
    
    
    
}





@end
