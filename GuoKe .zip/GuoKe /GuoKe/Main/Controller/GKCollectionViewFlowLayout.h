//
//  GKCollectionViewFlowLayout.h
//  GuoKe
//
//  Created by mac on 15/9/25.
//  Copyright (c) 2015年 dzk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GKCollectionViewFlowLayout : UICollectionViewFlowLayout

@end
