//
//  TopMessage.h
//  项目一01
//
//  Created by apple on 15/8/7.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "BaseViewController.h"

#import "MessageCell.h"

@interface TopMessage : BaseViewController<UITableViewDataSource,UITableViewDelegate>


@property (nonatomic ,strong) NSIndexPath *indexPath;



@end
