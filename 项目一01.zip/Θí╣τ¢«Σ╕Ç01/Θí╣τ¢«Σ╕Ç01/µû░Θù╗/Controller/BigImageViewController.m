//
//  BigImageViewController.m
//  项目一01
//
//  Created by apple on 15/8/6.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "BigImageViewController.h"

@interface BigImageViewController ()
{
//    状态栏是否隐藏
    BOOL _hiddenNavationBar;
}

@end

@implementation BigImageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self _createViews];
    
    self.title = @"图片浏览";
    
//    状态栏是否隐藏 设处之
    _hiddenNavationBar = NO;
    
    self.view.backgroundColor = [UIColor blackColor];
  
    
//    接受 隐藏 导航栏 的 通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hiddenNaviBar)
            name:kHiddenNavitionBar
          object:nil];
    
    
    
    
}

- (void)dealloc
{
//    移除通知
//    如果不移除，容易造成程序崩溃
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


- (void)_createViews
{
//    创建布局对象
    UICollectionViewFlowLayout *flow = [[UICollectionViewFlowLayout alloc] init];
    
//    设置单元格大小
    flow.itemSize = CGSizeMake(kScreenWith, kScreenHeight - 64);
    
//    设置单元格的水平间隙
    flow.minimumInteritemSpacing = 10;
    
//  设置四周间隙
    flow.sectionInset = UIEdgeInsetsMake(0, 0, 0, 10);
    
//    设置滑动方向
    flow.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
//    创建 colleacion
    _bigCell = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, kScreenWith + 10, kScreenHeight - 16) collectionViewLayout:flow];
    
    [self.view addSubview:_bigCell];
    
    _bigCell.backgroundColor = [UIColor blackColor];
    
//    注册单元格
    [_bigCell registerClass:[BigCell class] forCellWithReuseIdentifier:@"BigCell"];
    
//    设置数据源方法
    _bigCell.dataSource = self;
    
    _bigCell.delegate = self;
    
//    隐藏滑块
    _bigCell.showsHorizontalScrollIndicator = NO;
    
//    开启分页效果
    _bigCell.pagingEnabled = YES;
    
}

#pragma mark - 数据源方法

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _imageData.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    BigCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"BigCell" forIndexPath:indexPath];

//    _imageV = [[UIImageView alloc] initWithFrame:cell.bounds];

    NSURL *url;
    if (indexPath.row == 0)
    {
        url = _imageData[_indexPath.row];
    }
    else
    {
        url = _imageData[indexPath.row];
    }
    
    [cell setImageURl:url];

    return cell;
    
}



//隐藏 标签栏
- (void)viewWillAppear:(BOOL)animated
{
    MainTabBarController *mains = (MainTabBarController *)self.tabBarController;
    
    [mains setTabBarHidden:YES animation:YES];

}


- (void)viewDidAppear:(BOOL)animated
{
    [_bigCell scrollToItemAtIndexPath:_indexPath
                     atScrollPosition:UICollectionViewScrollPositionLeft
                             animated:NO];
    
    _indexPath = [NSIndexPath indexPathForItem:0 inSection:0];
}





#pragma mark - 隐藏导航栏
- (void)hiddenNaviBar
{
    _hiddenNavationBar = !_hiddenNavationBar;
    
//    根据当前
    [self.navigationController setNavigationBarHidden:_hiddenNavationBar animated:YES];
    
//    隐藏 导航栏 的同时 隐藏 状态栏
    UIApplication *app = [UIApplication sharedApplication];
    [app setStatusBarHidden:_hiddenNavationBar withAnimation:UIStatusBarAnimationFade];
}



#pragma mark - 某个单元格
- (void)collectionView:(UICollectionView *)collectionView didEndDisplayingCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    BigCell *big = (BigCell *)cell;
    
    [big backView];
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
