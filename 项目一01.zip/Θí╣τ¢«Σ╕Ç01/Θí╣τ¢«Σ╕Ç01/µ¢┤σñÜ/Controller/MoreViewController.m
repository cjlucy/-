//
//  MoreViewController.m
//  项目一01
//
//  Created by apple on 15/8/3.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "MoreViewController.h"

@interface MoreViewController ()

@end

@implementation MoreViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    

    self.title = @"更多";
    
}

- (long long)_countSize
{
    //    获取当前运用程序的沙河
    NSString *homePath = NSHomeDirectory();
    
    NSArray *subFilePath = @[@"/Library/Caches/com.hackemist.SDWebImageCache.default/",@"/Library/Caches/com.huiwenjiaoyu.---01/"];
    
    //        文件大小
    long long fileSize = 0;
    for (NSString *filePath in subFilePath)
    {
        //       拼接字符串  获取SDWebImage 的缓存文件夹
        NSString *subFile = [homePath stringByAppendingPathComponent:filePath];
        
        //      创建一个文件管理器  单例
        NSFileManager *fileManager = [NSFileManager defaultManager];//文件管理器（单例类）
        
        //       获取某个路径下所有文件的文件名
        NSArray *fileNames = [fileManager subpathsOfDirectoryAtPath:subFile error:nil];
        
        //       遍历文件夹
        for (NSString *fileName in fileNames)
        {
            //        拼接文件路径
            NSString *file = [subFile stringByAppendingPathComponent:fileName];
            
            //        根据文件路径 获取文件相关信息
            NSDictionary *dic = [fileManager attributesOfItemAtPath:file error:nil];
            fileSize += [dic[NSFileSize] longLongValue];
            
        }
    }
    _relaxLabel.text = [NSString stringWithFormat:@"%.2fMB",(CGFloat)fileSize / 1024 / 1024];
    
    return fileSize;
    

}

//当视图将要显示的时候，计算缓存文件大小
- (void)viewWillAppear:(BOOL)animated
{
    [self _countSize];
}

//选中单元格 ，删除缓存
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0)
    {
//        内存清理
        //    获取当前运用程序的沙河
        NSString *homePath = NSHomeDirectory();
        
        NSArray *subFilePath = @[@"/Library/Caches/com.hackemist.SDWebImageCache.default/",@"/Library/Caches/com.huiwenjiaoyu.---01/"];
        
        for (NSString *filePath in subFilePath)
         {
//           拼接字符串  获取SDWebImage 的缓存文件夹
            NSString *subFile = [homePath stringByAppendingPathComponent:filePath];
            
//          创建一个文件管理器  单例
            NSFileManager *fileManager = [NSFileManager defaultManager];//文件管理器（单例类）
            
//           获取某个路径下所有文件的文件名
            NSArray *fileNames = [fileManager subpathsOfDirectoryAtPath:subFile error:nil];
            
//           遍历文件夹
            for (NSString *fileName in fileNames)
            {
//              拼接文件路径
                NSString *file = [subFile stringByAppendingPathComponent:fileName];
                
//              根据文件路径 获取文件相关信息
                [fileManager removeItemAtPath:file error:nil];
            }
        }
        
        _relaxLabel.text = @"清理中...";
        
//        删除文件夹后，再次计算程序缓存文件大小
        [self performSelector:@selector(_countSize) withObject:nil afterDelay:1];
        
        
        
    }
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
