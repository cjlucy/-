//
//  TopViewController.h
//  项目一01
//
//  Created by apple on 15/8/3.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "BaseViewController.h"
#import "TopMessage.h"


@interface TopViewController : BaseViewController<UICollectionViewDataSource,UICollectionViewDelegate>




@end
