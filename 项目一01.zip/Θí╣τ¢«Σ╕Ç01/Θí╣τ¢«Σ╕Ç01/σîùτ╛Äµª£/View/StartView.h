//
//  StartView.h
//  项目一01
//
//  Created by apple on 15/8/6.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StartView : UIView

{
    UIView *_grayView;
    UIView *_yellowView;
}


- (void)setRating:(CGFloat)rating;



@end
