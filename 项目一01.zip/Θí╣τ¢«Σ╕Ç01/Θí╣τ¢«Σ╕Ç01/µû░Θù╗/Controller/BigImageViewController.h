//
//  BigImageViewController.h
//  项目一01
//
//  Created by apple on 15/8/6.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "BaseViewController.h"
#import "BigCell.h"


@interface BigImageViewController : BaseViewController<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
{
    UICollectionView *_bigCell;
    
//    UIImageView *_imageV;
    
}
@property (nonatomic , strong) NSArray *imageData;


@property (nonatomic , strong) NSIndexPath *indexPath;


@end
