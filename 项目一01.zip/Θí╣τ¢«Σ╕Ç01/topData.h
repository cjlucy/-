//
//  topData.h
//  项目一01
//
//  Created by apple on 15/8/6.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface topData : NSObject

@property (nonatomic , assign) CGFloat average;
@property (nonatomic , strong) NSDictionary *image;
@property (nonatomic , strong) NSString *title;

- (id)initWithDictionary:(NSDictionary *)dic;


@end
