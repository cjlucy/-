//
//  HeadCell.m
//  项目一01
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "HeadCell.h"

@implementation HeadCell

- (void)awakeFromNib
{
}

- (void)setMovie:(Movie *)movie
{
    _movie = movie;
    NSURL *url = [NSURL URLWithString:_movie.images[@"large"]];
    [_headImage sd_setImageWithURL:url];
    _headImage.contentMode = UIViewContentModeScaleAspectFit;

    
}

@end
