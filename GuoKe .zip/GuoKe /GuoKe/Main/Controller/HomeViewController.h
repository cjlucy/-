//
//  HomeViewController.h
//  GuoKe
//
//  Created by mac on 15/9/25.
//  Copyright (c) 2015年 dzk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "MJRefresh.h"
#define kMargin 10.f


#define times_news @"handpick/article.json"

@interface HomeViewController : BaseViewController





@end
