//
//  topData.m
//  项目一01
//
//  Created by apple on 15/8/6.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "topData.h"

@implementation topData

- (id)initWithDictionary:(NSDictionary *)dic
{
    self = [super init];
    if (self)
    {
//        获取平均分
        NSDictionary *d = dic[@"rating"];
        NSNumber *num = d[@"average"];
        _average = [num floatValue];
        
        _title = dic[@"title"];
        
//        NSDictionary *imagedic = dic[@"images"];
        _image = dic[@"images"];
         
    }
    return self;
}



@end
