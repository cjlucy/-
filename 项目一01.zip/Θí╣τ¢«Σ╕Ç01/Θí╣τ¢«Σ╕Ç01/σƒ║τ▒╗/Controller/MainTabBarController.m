//
//  MainTabBarController.m
//  项目一01
//
//  Created by apple on 15/8/3.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "MainTabBarController.h"

@interface MainTabBarController ()
{
    UIImageView *_TabBarImage;
    UIImageView *_selectImage;
    
}

@end

@implementation MainTabBarController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self _removeTabBar];
    
//    [self.tabBar setBackgroundImage:[UIImage imageNamed:@"tab_bg_all"]];
    
    [self _createTabBar];
    
    
}


- (void)_removeTabBar
{
    self.tabBar.hidden = YES;
}

#pragma mark - 自定义标签栏
//自定义 标签栏
- (void)_createTabBar
{
    _TabBarImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tab_bg_all"]];
    _TabBarImage.frame = CGRectMake(0, kScreenHeight - 49, kScreenWith, 49);
    
    [self.view addSubview:_TabBarImage];
    
    NSArray *images = @[@"movie_home",
                        @"msg_new",
                        @"icon_cinema",
                        @"start_top250",
                        @"more_select_setting"];
    NSArray *title = @[@"北美榜",
                       @"新闻",
                       @"影院",
                       @"top",
                       @"更多"];
    
    for (int i = 0; i < 5; i ++)
    {
        CGRect frame = CGRectMake(i * kScreenWith / 5, 0, kScreenWith / 5, 49);
        
        TabBarButton *button = [[TabBarButton alloc] initWithFrame:frame
                imageName:images[i]
                    title:title[i] ];
        button.tag = i;
        [button addTarget:self
                   action:@selector(buttonAction:)
         forControlEvents:UIControlEventTouchUpInside];
        
        [_TabBarImage addSubview:button];
        
    }
    _TabBarImage.userInteractionEnabled = YES;
    
    _selectImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"selectTabbar_bg_all@2x.png"]];
    _selectImage.frame = CGRectMake(0, 0, kScreenWith / 5, 49);
    
    [_TabBarImage insertSubview:_selectImage atIndex:0];
    
}

- (void)buttonAction:(UIButton *)button
{
    self.selectedIndex = button.tag;
    
    [UIView animateWithDuration:0.3 animations:^{
        _selectImage.center = button.center;
    
    }];
}


/**
 *  设置自定义的标签栏是否隐藏
 *
 *  @param hidden    是否隐藏
 *  @param animation 是否添加动画
 */
- (void)setTabBarHidden:(BOOL)hidden animation:(BOOL)animation
{
    if (animation)
    {
        // 隐藏动画
        [UIView animateWithDuration:0.3 animations:^{
            if (hidden)
            {
                _TabBarImage.top = kScreenHeight;
            }
            else
            {
                _TabBarImage.bottom = kScreenHeight;
            }
        }];
    }
    else
    {
        if (hidden)
        {
            _TabBarImage.top = kScreenHeight;
        }
        else
        {
            _TabBarImage.bottom = kScreenHeight;
        }
    }
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
