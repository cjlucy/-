//
//  DetaiViewContuoller.h
//  项目一01
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "BaseViewController.h"

@interface DetaiViewContuoller : BaseViewController

@end
