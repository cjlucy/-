//
//  HeadCell.h
//  项目一01
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Movie.h"

@interface HeadCell : UICollectionViewCell


@property (weak, nonatomic) IBOutlet UIImageView *headImage;

@property (nonatomic , strong) Movie *movie;

@end
