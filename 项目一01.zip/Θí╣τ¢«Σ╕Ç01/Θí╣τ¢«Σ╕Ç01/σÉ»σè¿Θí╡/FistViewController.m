
//  FistViewController.m
//  项目一01
//
//  Created by apple on 15/8/12.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "FistViewController.h"

@interface FistViewController ()
{
    UIScrollView *_scroll;
    
    UIImageView *_pageView;
    
    UIButton *_button;
}

@end

@implementation FistViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIApplication *app = [UIApplication sharedApplication];
    
    //    隐藏状态栏
    [app setStatusBarHidden:NO];

    [self _createViews];
    
}

- (void)_createViews
{
    _scroll = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    _scroll.pagingEnabled = YES;
    
    _scroll.delegate = self;
    
    _scroll.contentSize = CGSizeMake(5 * kScreenWith, 0);
    
    [self.view addSubview:_scroll];
    
    for (int i = 0; i < 5; i++)
    {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(i * kScreenWith, 0, kScreenWith, kScreenHeight)];
        
//        拼接图片
        NSString *imageName = [NSString stringWithFormat:@"guide%i",i + 1];
        UIImage *image = [UIImage imageNamed:imageName];
        
        imageView.image = image;
        [_scroll addSubview:imageView];
        
        
    }
    
    _pageView = [[UIImageView alloc] initWithFrame:CGRectMake((kScreenWith - 173) / 2, kScreenHeight - 26, 173, 26)];
    _pageView.image = [UIImage imageNamed:@"guideProgress1"];
    [self.view addSubview:_pageView];
    
    
//    进入按钮
    
    _button = [UIButton buttonWithType:UIButtonTypeCustom];
    _button.frame = CGRectMake((kScreenWith - 200) / 2, kScreenHeight - 100, 200, 40);
    [_button setTitle:@"进入电影" forState:UIControlStateNormal];
    [_button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    _button.hidden = YES;
    [_button addTarget:self
                action:@selector(showMainViewController) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:_button];
    
    
}

//滑动视图滑动的方法
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
//    根据偏移量来计算当前页数
    CGFloat x = scrollView.contentOffset.x;
    NSInteger index = (x + kScreenWith / 2) / kScreenWith;
    
    NSArray *imageNames = @[@"guideProgress1",
                            @"guideProgress2",
                            @"guideProgress3",
                            @"guideProgress4",
                            @"guideProgress5"];
    
    UIImage *image = [UIImage imageNamed:imageNames[index]];
    _pageView.image = image;
    
    if (index == 4)
    {
        _button.hidden = NO;
    }
    else
    {
        _button.hidden = YES;
    }
    
}

- (void)showMainViewController
{
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    
    UIViewController *vc = [story instantiateInitialViewController];
    
    self.view.window.rootViewController = vc;
    
    //    视图显示的动画
    vc.view.transform = CGAffineTransformMakeScale(0.2, 0.2);
    
    [UIView animateWithDuration:0.3 animations:^{
        vc.view.transform = CGAffineTransformIdentity;
    }];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    [userDefaults setBool:@YES forKey:@"first"];
}





//内存泄漏调用的方法
//当发送了三次内存警告后，程序所占用内存仍旧超出范围，就会强行停止程序
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
//    全局变量都置空
    
//    最后
    self.view = nil;
}


@end
