//
//  HeadCollectionView.m
//  项目一01
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "HeadCollectionView.h"

@implementation HeadCollectionView


- (instancetype)initWithFrame:(CGRect)frame itemSize:(CGSize)itemSize
{
    self = [super initWithFrame:frame itemSize:itemSize];
    if (self)
    {
        UINib *nib = [UINib nibWithNibName:@"HeadCell" bundle:[NSBundle mainBundle]];
        [self registerNib:nib forCellWithReuseIdentifier:@"headCell"];
    }
    return self;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HeadCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"headCell" forIndexPath:indexPath];
    
        cell.movie = self.movieDatas[indexPath.row];

    return cell;
}


// 点击单元格 滑动
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
  
    [collectionView scrollToItemAtIndexPath:indexPath
                               atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally
                                   animated:YES];
    
    self.currentIndex = indexPath.item;
    
    
}





@end
