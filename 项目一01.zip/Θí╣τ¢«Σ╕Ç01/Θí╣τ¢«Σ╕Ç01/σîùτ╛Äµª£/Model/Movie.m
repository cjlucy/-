//
//  Movie.m
//  项目一01
//
//  Created by apple on 15/8/7.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "Movie.h"

@implementation Movie

- (id)initWithDictionary:(NSDictionary *)dic
{
    self = [super init];
    
    if (self)
    {
        //        将字典里的数据 读取出来储存到属性中
        
        //        获取 subject 字典
        NSDictionary *subDic = dic[@"subject"];
        _titleCN = subDic[@"title"];
        _titleEN = subDic[@"original_title"];
        
        //        读取平均分
        NSDictionary *ratingDic = subDic[@"rating"];
        NSNumber *averageNumber = ratingDic[@"average"];
        _reating = [averageNumber floatValue];
        
        _images = subDic[@"images"];
        _year = subDic[@"year"];
        
    }
    return self;
}




@end
