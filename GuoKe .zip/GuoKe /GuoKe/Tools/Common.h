//
//  Common.h
//  GuoKe
//
//  Created by mac on 15/9/25.
//  Copyright (c) 2015年 dzk. All rights reserved.
//

#ifndef GuoKe_Common_h
#define GuoKe_Common_h

//屏幕宽高
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

//新浪微博
#define kAppKey             @"1866520408"
#define kAppSecret          @"33cfd1d72f909a3fd0f5d10aeab4d252"
#define kAppRedirectURI     @"https://api.wei.com/oauth2/default.html"


#define GKtoken @"05f92a831bb0a125c70ff60c39ea51fa455a017595965035633044f6bc917c9b"
#define commentUrl @"handpick/reply.json"
#define collectionKey @"collectionKey"
#define collectCancal @"qwertyui"


#define switchStateOn @"switchStateOn"
#define switchStateOff @"switchStateOff"

#endif



