//
//  BaseViewController.m
//  项目一01
//
//  Created by apple on 15/8/3.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()
{
    UILabel *_titleLabel;
}

@end

@implementation BaseViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self _createLabel];
    
    
    
    
}

- (void)_createLabel
{
    _titleLabel = [[UILabel alloc] init];
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.frame = CGRectMake(0, 0, 200, 40);
    _titleLabel.font = [UIFont boldSystemFontOfSize:30];

    
    self.navigationItem.titleView = _titleLabel;
}

// 在使用 self.title 的设置器方法时，修改titleLabel的显示文字
- (void)setTitle:(NSString *)title
{
    [super setTitle:title];
    _titleLabel.text = title;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
