//
//  messageData.h
//  项目一01
//
//  Created by apple on 15/8/7.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "messageData.h"

@interface messageData : NSObject

/*
//movie_detail
@property (nonatomic , strong) NSString *image;//电影图片
@property (nonatomic , strong) NSString *titleCn;//电影名
@property (nonatomic , strong) NSArray *directors;//导演
@property (nonatomic , strong) NSArray *actors;//演员
@property (nonatomic , strong) NSArray *type;//类型
@property (nonatomic , strong) NSString *location;//地区
@property (nonatomic , strong) NSArray *images;//上映日期
*/

@property (nonatomic , strong) NSString *userImage;
@property (nonatomic , strong) NSString *nickname;
@property (nonatomic , strong) NSString *content;
@property (nonatomic , strong) NSString *rating;

- (id)initWitdDictionary:(NSDictionary *)dic;

@end
