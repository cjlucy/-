
//  StartViewController.m
//  项目一01
//
//  Created by apple on 15/8/12.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "StartViewController.h"

@interface StartViewController ()
{
    NSTimer *_timer;
}

@end

@implementation StartViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIApplication *app = [UIApplication sharedApplication];
    
//    隐藏状态栏
    [app setStatusBarHidden:YES];
    
    [self hiddenView];
    
    _timer = [NSTimer scheduledTimerWithTimeInterval:0.1
                                     target:self
                                   selector:@selector(showImageView:)
                                   userInfo:nil repeats:YES];
    
    
}

- (void)hiddenView
{
    for (int i = 1; i < 29; i++)
    {
         UIView *imageView = [self.view viewWithTag:i];
        imageView.hidden = YES;
    }
}


- (void)showImageView:(NSTimer *)time
{
    static int tag = 1;
    UIView *imageView = [self.view viewWithTag:tag];
    [UIView animateWithDuration:0.1 animations:^{
        imageView.hidden = NO;
    }];
    tag ++;
    
    if (tag == 29)
    {
        [_timer invalidate];
        
        [self performSelector:@selector(showMainViewController) withObject:nil afterDelay:1];
    }
}

- (void)showMainViewController
{
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    
    UIViewController *vc = [story instantiateInitialViewController];
    
    self.view.window.rootViewController = vc;
    
//    视图显示的动画
    vc.view.transform = CGAffineTransformMakeScale(0.2, 0.2);
    
    [UIView animateWithDuration:0.3 animations:^{
        vc.view.transform = CGAffineTransformIdentity;
    }];
    
}















- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
