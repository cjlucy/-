//
//  News.m
//  项目一01
//
//  Created by apple on 15/8/5.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "News.h"

@implementation News

// 重写 方法

- (id)initContentWithDic:(NSDictionary *)jsonDic
{
    self = [super initContentWithDic:jsonDic];
    if (self)
    {
        self.newsID = jsonDic[@"id"];
        
    }
    return self;
}




@end
