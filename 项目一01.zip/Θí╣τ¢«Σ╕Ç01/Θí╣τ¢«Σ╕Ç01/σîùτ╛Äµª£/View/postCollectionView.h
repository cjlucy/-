//
//  postCollectionView.h
//  项目一01
//
//  Created by apple on 15/8/10.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "BaseCollectionView.h"

#import "PostCollectionViewCell.h"

@interface postCollectionView : BaseCollectionView


@property (nonatomic , strong) NSMutableArray *imagegData;




@end
