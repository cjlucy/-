//
//  StartView.m
//  项目一01
//
//  Created by apple on 15/8/6.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "StartView.h"

@implementation StartView
- (instancetype)initWithFrame:(CGRect)frame
{
    //    强制让视图的宽高成比例，能够完整显示五颗星
    CGFloat width = frame.size.height / 17 * 17.5 * 5;
    frame.size.width = width;
    self = [super initWithFrame:frame];
    if (self)
    {
        [self _createStartView];
    }
    return self;
}

- (void)awakeFromNib
{
    
    //    强制让视图的宽高成比例，能够完整显示五颗星
    
    CGFloat width = self.frame.size.height / 17 * 17.5 * 5;
    self.width = width;
    
    [self _createStartView];
    
}

- (void)_createStartView
{
    //    创建灰色✨
    _grayView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 17.5 * 5, 17)];
    _grayView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"gray@2x"]];
    [self addSubview:_grayView];
    
    //    创建黄色✨
    _yellowView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 17.5 * 5, 17)];
    _yellowView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"yellow@2x"]];
    [self addSubview:_yellowView];
    
    CGFloat scale = self.size.height / 17;
    
    CGAffineTransform transform = CGAffineTransformMakeScale(scale , scale);
    
    _grayView.transform = transform;
    _yellowView.transform = transform;
    
    
    _grayView.frame = self.bounds;
    _yellowView.frame = self.bounds;
    
    
    
    
}


- (void)setRating:(CGFloat)rating
{
    if (rating < 0 || rating > 10)
    {
        return;
    }
    
    _yellowView.width = _grayView.width * rating / 10 ;
}




@end
