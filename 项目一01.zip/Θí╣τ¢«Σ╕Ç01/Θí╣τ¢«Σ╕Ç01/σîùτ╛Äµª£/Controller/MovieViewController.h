//
//  MovieViewController.h
//  项目一01
//
//  Created by apple on 15/8/3.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "BaseViewController.h"
#import "MovieCell.h"
#import "postCollectionView.h"
#import "HeadCollectionView.h"

@interface MovieViewController : BaseViewController<UITableViewDataSource>
{
//    头部视图所有视图的父视图
    UIView *_headView;
    
//    灯
    UIImageView *_leftLight;
    UIImageView *_rightLight;
    
    UIView *_markView;
    
//    头视图，滑动视图
    HeadCollectionView *_headCollectionView;
    
    UIButton *_upDownButton;
    
    NSMutableArray *_movieTitle;
}

//存放数据
@property (nonatomic , strong)  NSMutableArray *movieData;

@property (nonatomic , strong) UILabel *movieLabel;


@end
