//
//  MovieCell.m
//  项目一01
//
//  Created by apple on 15/8/7.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "MovieCell.h"

@implementation MovieCell

- (void)awakeFromNib {
    // Initialization code
}


- (void)setMovie:(Movie *)movie
{
    _movie = movie;
    _movieName.text = _movie.titleCN;
    _screenYear.text = [NSString stringWithFormat:@"上映年份：%@",_movie.year];
    
    //    评分
    _mark.text = [NSString stringWithFormat:@"%.1f",_movie.reating];
    
    //    电影图片
    NSURL *url = [NSURL URLWithString:_movie.images[@"large"]];
    [_movieImages sd_setImageWithURL:url];
    
    
    //    评分视图
    [_startViews setRating:_movie.reating];
    
}











- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
