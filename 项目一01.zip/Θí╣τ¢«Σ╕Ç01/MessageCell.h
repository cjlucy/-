//
//  MessageCell.h
//  项目一01
//
//  Created by apple on 15/8/8.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "messageData.h"

@interface MessageCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *movieImage;

@property (weak, nonatomic) IBOutlet UILabel *userTitle;

@property (weak, nonatomic) IBOutlet UILabel *contenTitle;

@property (weak, nonatomic) IBOutlet UILabel *mark;

@property (nonatomic , strong) messageData *messagedata;

@end
