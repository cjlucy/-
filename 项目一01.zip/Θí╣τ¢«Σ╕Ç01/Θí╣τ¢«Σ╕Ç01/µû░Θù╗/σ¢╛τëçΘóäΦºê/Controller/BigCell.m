//
//  BigCell.m
//  项目一01
//
//  Created by apple on 15/8/8.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "BigCell.h"

@implementation BigCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        [self _createView];
        [self _addtap];

    }
    return self;
}

- (void)_createView
{
    //        创建滑动视图
    UIScrollView *scrollview = [[UIScrollView alloc] initWithFrame:self.bounds];
    scrollview.tag = 666;
    [self.contentView addSubview:scrollview];
    
    _imageView = [[UIImageView alloc] initWithFrame:self.contentView.bounds];
    [scrollview addSubview:_imageView];
    
    _imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    //        设置代理
    scrollview.delegate = self;
    
    scrollview.minimumZoomScale = 0.3;
    scrollview.maximumZoomScale = 3;
}



- (void)setImageURl:(NSURL *)url
{
    [_imageView sd_setImageWithURL:url];
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return _imageView;
}

//添加点击事件
- (void)_addtap
{
//    点击手势识别器
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
    
//    点击1次
    tap1.numberOfTapsRequired = 1;
    
//    点击手指数量
    tap1.numberOfTouchesRequired = 1;
    
//    添加执行方法
    [tap1 addTarget:self
             action:@selector(tapAction:)];
    
    [self addGestureRecognizer:tap1];
    
    
    //    点击手势识别器
    UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc] init];
    
    //    点击1次
    tap2.numberOfTapsRequired = 2;
    
    //    点击手指数量
    tap2.numberOfTouchesRequired = 1;
    
    //    添加执行方法
    [tap2 addTarget:self
             action:@selector(tapAction:)];
    
    [self addGestureRecognizer:tap2];

}

- (void)tapAction:(UITapGestureRecognizer *)tap
{
    if (tap.numberOfTapsRequired == 2)
    {
//        双击
        NSLog(@"1234");
        [_timer invalidate];
        [self tapTwoAction];
        
    }
    else if (tap.numberOfTapsRequired == 1)
    {
//        单击
        _timer = [NSTimer scheduledTimerWithTimeInterval:0.5
                                    target:self selector:@selector(tapOneAction) userInfo:nil repeats:NO];
        
    }
}

/**
 *   单双击的区分
// 单击，导航栏隐藏；
// 双击，放大，缩小；
 */

- (void)timeAction
{
   
}

//单击事件，隐藏导航栏
- (void)tapOneAction
{
//    通知
    NSLog(@"zxcvbhjkdfghjxcvhxcv");
    [[NSNotificationCenter defaultCenter] postNotificationName:kHiddenNavitionBar object:nil];
    
}




//双击事件,图片放大缩小
- (void)tapTwoAction
{
//    判断当前缩放状态
    UIScrollView *scroll = (UIScrollView *)[self.contentView viewWithTag:666];
    CGFloat scale = scroll.zoomScale;
    if (scale > 2)
    {
        [scroll setZoomScale:1 animated:YES];
    }
    else
    {
//        将图片放大
        [scroll setZoomScale:3 animated:YES];
    }
}



//还原滑动视图的缩放比例
- (void)backView
{
    UIScrollView *scroll = (UIScrollView *)[self.contentView viewWithTag:666];
    
    //    改变滑动视图的缩放比例
    [scroll setZoomScale:1 animated:YES];

}



@end
