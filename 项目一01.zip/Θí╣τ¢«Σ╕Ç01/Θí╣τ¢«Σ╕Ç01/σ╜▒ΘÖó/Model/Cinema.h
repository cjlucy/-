//
//  Cinema.h
//  项目一01
//
//  Created by apple on 15/8/12.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Cinema : NSObject

/*
 "lowPrice" : "40.00",
 "grade" : "8.8",
 "distance" : null,
 "address" : "北京市海淀区学清路甲8号，圣熙8号购物中心五层西侧。",
 "name" : "嘉华国际影城",
 "districtId" : "1015",

 "isSeatSupport" : "1", //座位
 "isCouponSupport" : "1", //券
// "isGroupBuySupport" : "0",／／集团优惠


 */

@property (nonatomic , strong) NSString *lowPrice;

@property (nonatomic , strong) NSString *grade;

@property (nonatomic , strong) NSString *distance;

@property (nonatomic , strong) NSString *address;

@property (nonatomic , strong) NSString *name;

@property (nonatomic , strong) NSString *districtId;

@property (nonatomic , strong) NSString *isSeatSupport;

@property (nonatomic , strong) NSString *isCouponSupport;

@property (nonatomic , strong) NSString *isGroupBuySupport;



- (instancetype)initWithDictionary:(NSDictionary *)dic;


@end
