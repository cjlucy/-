//
//  ImageViewController.m
//  项目一01
//
//  Created by apple on 15/8/5.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "ImageViewController.h"

@interface ImageViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource>
{
    NSMutableArray *_imageArray;
}


@end

@implementation ImageViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    self.title = @"新闻图片";
    [self _loadData];
}


- (void)_loadData
{
    NSString *filepath = [[NSBundle mainBundle] pathForResource:@"image_list副本" ofType:@"json"];
    //    2.读取文件
    NSData *data = [NSData dataWithContentsOfFile:filepath];
    //    3.解析文件
    NSError *error = [[NSError alloc] init];
    NSArray *array = [NSJSONSerialization JSONObjectWithData:data
                                                     options:NSJSONReadingMutableLeaves
                                                       error:&error];
    
    _imageArray = [[NSMutableArray alloc] init];
    for (NSDictionary *dic in array)
    {
        [_imageArray addObject:dic[@"image"]];
    }
 
}



- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _imageArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"imageCell" forIndexPath:indexPath];
    
//    cell.backgroundColor = [UIColor orangeColor];
    
    // 获取imageview
    UIImageView *iv = (UIImageView *)[cell.contentView viewWithTag:123];

    [iv sd_setImageWithURL:[NSURL URLWithString:
                            _imageArray[indexPath.row]]];
    
//    图片大小
    iv.contentMode = UIViewContentModeScaleAspectFill;
    
//   视图边框
    cell.layer.cornerRadius = 5;
    
//    设置边框颜色
    cell.layer.borderColor = [[UIColor blueColor]CGColor];
    
//    设置边框
    cell.layer.borderWidth = 3;
    
    return cell;
}


- (void)viewWillDisappear:(BOOL)animated
{
    MainTabBarController *main = (MainTabBarController *)self.tabBarController;
    
    [main setTabBarHidden:NO animation:YES];
    
}



//单元格被选中
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    BigImageViewController *big = [[BigImageViewController alloc] init];
    
    big.imageData = _imageArray;
    
    big.indexPath = indexPath;
    
    [self.navigationController pushViewController:big animated:YES];
}













- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}






@end
