//
//  CinemaViewController.h
//  项目一01
//
//  Created by apple on 15/8/3.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "BaseViewController.h"
#import "Cinema.h"
#import "CinemaCell.h"

@interface CinemaViewController : BaseViewController<UITableViewDataSource,UITableViewDelegate>


{
    NSMutableArray *_cinemaData;
    
    NSMutableArray *_newCinemaData;
    
    NSArray *_districtData;
    
    

    
   BOOL _isShow[100];
    
}

@property (weak, nonatomic) IBOutlet UITableView *cinemaTableView;




@end
