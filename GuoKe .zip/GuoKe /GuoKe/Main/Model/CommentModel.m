//
//  CommentModel.m
//  GuoKe
//
//  Created by mac on 15/9/29.
//  Copyright (c) 2015年 dzk. All rights reserved.
//

#import "CommentModel.h"

@implementation CommentModel

@end
