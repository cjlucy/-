//
//  HeadCollectionView.h
//  项目一01
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "BaseCollectionView.h"
#import "HeadCell.h"

@interface HeadCollectionView : BaseCollectionView

@end
