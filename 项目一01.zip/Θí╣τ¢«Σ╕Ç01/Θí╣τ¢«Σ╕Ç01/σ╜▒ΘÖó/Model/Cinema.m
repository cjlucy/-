//
//  Cinema.m
//  项目一01
//
//  Created by apple on 15/8/12.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "Cinema.h"

@implementation Cinema

- (instancetype)initWithDictionary:(NSDictionary *)dic
{
    self = [super init];
    if (self)
    {
        _lowPrice = dic[@"lowPrice"];
        _grade = dic[@"grade"];
        _distance = dic[@"distance"];
        _address = dic[@"address"];
        _name = dic[@"name"];
        _districtId = dic[@"districtId"];
        _isSeatSupport = dic[@"isSeatSupport"];
        _isCouponSupport = dic[@"isCouponSupport"];
        _isGroupBuySupport = dic[@"isGroupBuySupport"];
    }
    
    return self;
}






@end
