//
//  messageData.m
//  项目一01
//
//  Created by apple on 15/8/7.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "messageData.h"

@implementation messageData

- (id)initWitdDictionary:(NSDictionary *)dic
{
    self = [super init];
    if (self)
    {
        _userImage = dic[@"userImage"];
        _nickname = dic[@"nickname"];
        _content = dic[@"content"];
        _rating = dic[@"rating"];
    }
    return self;
}



@end
