//
//  BaseCollectionView.h
//  项目一01
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Movie.h"



@interface BaseCollectionView : UICollectionView<UICollectionViewDataSource,UICollectionViewDelegate>

@property (nonatomic , strong) NSMutableArray *movieDatas;


@property (nonatomic , assign) CGSize itemSize;


@property (nonatomic , assign) NSInteger currentIndex;



- (instancetype)initWithFrame:(CGRect)frame itemSize:(CGSize )itemSize;



@end
