//
//  MovieCell.h
//  项目一01
//
//  Created by apple on 15/8/7.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Movie.h"

@interface MovieCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UIImageView *movieImages;

@property (weak, nonatomic) IBOutlet UILabel *movieName;

@property (weak, nonatomic) IBOutlet UILabel *screenYear;

@property (weak, nonatomic) IBOutlet UILabel *mark;

@property (weak, nonatomic) IBOutlet UIView *startView;

@property (weak, nonatomic) IBOutlet StartView *startViews;





@property(nonatomic,strong) Movie *movie;



@end
