//
//  MyCommentViewController.m
//  GuoKe
//
//  Created by mac on 15/9/25.
//  Copyright (c) 2015年 dzk. All rights reserved.
//

#import "MyCommentViewController.h"

@interface MyCommentViewController () <UITextViewDelegate>
{
    UILabel *_emailLabel;
    UITextView *_textView1;
    
    UILabel *_adviceLabel;
    UITextView *_textView2;
    
    UIButton *_button;
}
@end

@implementation MyCommentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"请吐槽";
    self.view.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1];
    
    [self _createView];
}
- (void)_createView
{
    _emailLabel = [[UILabel alloc] initWithFrame:CGRectMake(40, 64+5, 100, 30)];
    _emailLabel.text = @"联系邮箱";
    _emailLabel.textColor = [UIColor blackColor];
    
    _textView1 = [[UITextView alloc] initWithFrame:CGRectMake(40, _emailLabel.bottom+5, kScreenWidth - 80, 50)];
    _textView1.backgroundColor = [UIColor whiteColor];
    
    _adviceLabel = [[UILabel alloc] initWithFrame:CGRectMake(40, _textView1.bottom+5, 100, 30)];
    _adviceLabel.text = @"您的建议";
    _adviceLabel.textColor = [UIColor blackColor];
    
    _textView2 = [[UITextView alloc] initWithFrame:CGRectMake(40, _adviceLabel.bottom+5, kScreenWidth - 80, 250)];
    _textView2.backgroundColor = [UIColor whiteColor];
    
    
    _textView1.delegate = self;
    _textView2.delegate = self;
    
//    添加button
    _button = [[UIButton alloc] initWithFrame:self.view.bounds];
    _button.backgroundColor = [UIColor clearColor];
    [_button addTarget:self action:@selector(buttonAction) forControlEvents:UIControlEventTouchUpInside];
    
//    [self.view addSubview:button];
    
    [self.view addSubview:_emailLabel];
    [self.view addSubview:_adviceLabel];
    [self.view addSubview:_textView1];
    [self.view addSubview:_textView2];
    
    
    //提交按钮
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"提交" style:UIBarButtonItemStylePlain target:self action:@selector(submitAction:)];
}

//提交按钮
- (void)submitAction:(UIButton *)button{
    if (_textView1.text.length == 0) {
        UIAlertView *alterView = [[UIAlertView alloc] initWithTitle:@"请填写邮箱" message:@"咦？要填写邮箱哦～" delegate:self cancelButtonTitle:@"好吧" otherButtonTitles:nil, nil];
        [alterView show];
    }else if (_textView2.text.length == 0){
        UIAlertView *alterView = [[UIAlertView alloc] initWithTitle:@"请填写意见" message:@"欢迎填写意见" delegate:self cancelButtonTitle:@"好吧" otherButtonTitles:nil, nil];
        [alterView show];
    }
    
    [_textView1 resignFirstResponder];
    [_textView2 resignFirstResponder];
    [_button removeFromSuperview];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)buttonAction
{
    //    取消键盘第一响应
    [_textView1 resignFirstResponder];
    [_textView2 resignFirstResponder];
    [_button removeFromSuperview];
}

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    [self.view addSubview:_button];
    [self.navigationController.view addSubview:_button];
}


@end
