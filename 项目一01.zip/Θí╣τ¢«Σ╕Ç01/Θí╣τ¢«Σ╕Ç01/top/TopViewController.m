//
//  TopViewController.m
//  项目一01
//
//  Created by apple on 15/8/3.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "TopViewController.h"

@interface TopViewController ()
{
    NSMutableArray *_topDatas;
}

@end

@implementation TopViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    self.title = @"Top250";
    [self _loadData];
    
//    将返回时的文字改为 白色
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    
    
}


- (void)_loadData
{
//    1.读取文件路径
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"top250" ofType:@"json"];
    //    2.读取文件
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    //    3.解析文件
    NSError *error = [[NSError alloc] init];
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data
                                                        options:NSJSONReadingMutableLeaves
                                                          error:&error];
    _topDatas = [[NSMutableArray alloc] init];
    for (NSDictionary *newdic in dic[@"subjects"])
    {
        topData *topdata = [[topData alloc] initWithDictionary:newdic];
        [_topDatas addObject:topdata];
    }
    
}





#pragma mark - collection 数据源方法

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _topDatas.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{

    TopCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"TopCell" forIndexPath:indexPath];

    cell.topdata = _topDatas[indexPath.row];
    
    
    
    return cell;
    
}



- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    TopMessage *topmessage = [[TopMessage alloc] init];
    
//    隐藏状态栏
    MainTabBarController *mains = (MainTabBarController *)self.tabBarController;
    
    [mains setTabBarHidden:YES animation:YES];
    

    [self.navigationController pushViewController:topmessage animated:YES];
}

//显示状态栏
- (void)viewWillAppear:(BOOL)animated
{
    MainTabBarController *mains = (MainTabBarController *)self.tabBarController;
    
    
    [mains setTabBarHidden:NO animation:YES];
    
    
}










- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}






@end
