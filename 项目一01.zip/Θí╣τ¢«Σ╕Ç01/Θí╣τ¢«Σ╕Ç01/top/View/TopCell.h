//
//  TopCell.h
//  项目一01
//
//  Created by apple on 15/8/6.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StartView.h"
#import "topData.h"

@interface TopCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *topImageView;

@property (weak, nonatomic) IBOutlet StartView *topStartView;


@property (weak, nonatomic) IBOutlet UILabel *markLabel;

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;




@property (nonatomic , strong) topData *topdata;




@end
