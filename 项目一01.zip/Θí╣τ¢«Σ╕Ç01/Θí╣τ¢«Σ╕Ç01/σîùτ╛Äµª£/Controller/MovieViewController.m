//  MovieViewController.m
//  项目一01
//
//  Created by apple on 15/8/3.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "MovieViewController.h"

@interface MovieViewController ()
{
    UIButton *_rightButton;
    
    NSInteger _currentIndex;
    
    postCollectionView *_postView;

    __weak IBOutlet UITableView *_listView;
    

}

@end

@implementation MovieViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"北美榜";
//
    
    //    读取数据
    [self _loadData];
    
    [self _createRightButton];
    [self _createViews];
    
//    创建头部视图
    [self _createHeadView];
    
// 观察者模式
   [_postView addObserver:self
               forKeyPath:@"currentIndex"
                  options:NSKeyValueObservingOptionNew
                  context:nil];
    
   [_headCollectionView addObserver:self
               forKeyPath:@"currentIndex"
                  options:NSKeyValueObservingOptionNew context:nil];
    
}

//观察者方法
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
//    获取值
    _currentIndex = [change[@"new"] integerValue];
    NSLog(@"%li",_currentIndex);
    
//    滑动视图 显示这个单元格
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:_currentIndex inSection:0];
    if (object == _postView && _currentIndex != _headCollectionView.currentIndex)
    {
        [_headCollectionView scrollToItemAtIndexPath:indexPath
                                    atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally
                                            animated:YES];
    }
    else if (object == _headCollectionView && _postView.currentIndex != _currentIndex)
    {
        [_postView scrollToItemAtIndexPath:indexPath
                          atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally
                                  animated:YES];
        _postView.currentIndex = _currentIndex;
    }
    
    Movie *movie = _movieData[_currentIndex];
    NSString *title = movie.titleCN;
    _movieLabel.text = title;

    
}




#pragma mark - 数据读取
- (void)_loadData
{
    //    1.读取文件路径
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"us_box" ofType:@"json"];
    
    //    2.读取文件
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    //    3.解析文件
    NSError *error = [[NSError alloc] init];
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data
                                                        options:NSJSONReadingMutableLeaves
                                                          error:&error];
    
    _movieData = [[NSMutableArray alloc] init];
    
    for (NSDictionary *d in dic[@"subjects"])
    {
        Movie *movie = [[Movie alloc] initWithDictionary:d];
        
        [_movieData addObject:movie];
        
    }
    
    

    
}




#pragma mark - 创建右上角按钮

- (void)_createRightButton
{
    _rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _rightButton.frame = CGRectMake(0, 0, 49, 25);
    [_rightButton setBackgroundImage:[UIImage imageNamed:@"exchange_bg_home@2x.png"] forState:UIControlStateNormal];
    [_rightButton setImage:[UIImage imageNamed:@"list_home@2x.png"] forState:UIControlStateNormal];
    [_rightButton setImage:[UIImage imageNamed:@"movie_home@2x.png"] forState:UIControlStateSelected];
    UIBarButtonItem *ButtonItem = [[UIBarButtonItem alloc]initWithCustomView:_rightButton];
    self.navigationItem.rightBarButtonItem = ButtonItem;
    
    //
    [_rightButton addTarget:self
                     action:@selector(ButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
}

//按钮点击事件 正反面翻转
- (void)ButtonAction:(UIButton *)button
{
    
    //    根据按钮的选中状态 来设置旋转方向
    UIViewAnimationOptions option = button.selected ?
    UIViewAnimationOptionTransitionFlipFromLeft : UIViewAnimationOptionTransitionFlipFromRight;
    
    
    //给某个视图 加动画
    [UIView transitionWithView:button  //需要加动画的视图
                      duration:0.3     //动画持续时间
                       options:option   //旋转方向
                    animations:^{
                        button.selected = !button.selected;
                    }
                    completion:nil];
    
    
    [UIView transitionWithView:self.view  //需要加动画的视图
                      duration:0.3     //动画持续时间
                       options:option   //旋转方向
                    animations:^{
                        _listView.hidden = button.selected;
                        _postView.hidden = !button.selected;
                        _movieLabel.hidden = !button.selected;
            
//                        头视图隐藏与否
                        _headView.hidden = !button.selected;
                    }
                    completion:nil];
    
    
    if (button.selected)
    {
        [button setImage:[UIImage imageNamed:@"poster_home@2x"] forState:UIControlStateHighlighted];
    }
    else
    {
        [button setImage:[UIImage imageNamed:@"list_home@2x"] forState:UIControlStateHighlighted];
        
    }

    
}

#pragma mark - 创建中间视图 (海报，列表)
- (void)_createViews
{
//    创建海报视图 背面
    _postView = [[postCollectionView alloc] initWithFrame:CGRectMake(0, 0, kScreenWith, kScreenHeight + 10) itemSize:CGSizeMake(kScreenWith * 0.65, kScreenHeight * 0.65)];
    _postView.backgroundColor = [UIColor blackColor];
    _postView.hidden = YES;
 
    [self.view addSubview:_postView];
 
//    创建图片下对应的电影名
        _movieLabel = [[UILabel alloc] initWithFrame:CGRectMake(kScreenWith / 2 - 100,  kScreenHeight * 0.84, 200, 50)];
        _movieLabel.hidden = YES;
    
//    设置电影名字
     Movie *movie = _movieData[0];
    NSString *title = movie.titleCN;
    _movieLabel.textColor = [UIColor whiteColor];
    _movieLabel.text = title;
    _movieLabel.textAlignment = NSTextAlignmentCenter;
    
    [self.view addSubview:_movieLabel];


    
//   正面 表视图
    _listView.dataSource = self;

//   设置表视图背景
    _listView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main@2x"]];
//    行高
    _listView.rowHeight = 120;
    
}

#pragma mark - 数据源方法  正面
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _movieData.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MovieCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil)
    {
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"MovieCell"
                                                       owner:nil
                                                     options:nil];
        cell = [array lastObject];
        
        cell.backgroundColor = [UIColor clearColor];
        
    }
    
//        单元格数据导入
    cell.movie = _movieData[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark - 创建 中间 滑动 视图 背面

- (void)_createHeadView
{
//    创建遮罩视图
    _markView = [[UIView alloc] initWithFrame:self.view.bounds ];
    
    _markView.backgroundColor = [UIColor blackColor];
    
//    _markView.top = 64;
    _markView.alpha = 0.4;
    _markView.hidden = YES;
    [self.view addSubview:_markView];
    
//    点击黑色视图，收起头部视图
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headViewMoveUp)];
    [_markView addGestureRecognizer:tap];

    
//    手指轻滑
    UISwipeGestureRecognizer *swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(headViewMoveDown)];
    swipe.direction = UISwipeGestureRecognizerDirectionDown;
    
    [_postView addGestureRecognizer:swipe];
    
    
//    创建父视图
    _headView = [[UIView alloc] initWithFrame:CGRectMake(0, -45, kScreenWith,130)];
    [self.view addSubview:_headView];
    _headView.hidden = YES;
    _headView.backgroundColor = [UIColor blackColor];

    
//  创建背景视图
    UIImageView *headBackView = [[UIImageView alloc] initWithFrame:_headView.bounds];
    
    UIImage *backImage = [UIImage imageNamed:@"indexBG_home@2x.png"];
    
//    拉伸图片
    backImage = [backImage stretchableImageWithLeftCapWidth:0 topCapHeight:3];
    headBackView.image = backImage;
    
    [_headView addSubview:headBackView];

    
//    创建collectionview
    _headCollectionView = [[HeadCollectionView alloc] initWithFrame:CGRectMake(0,0, kScreenWith, 100) itemSize:CGSizeMake(60, 90)];
    
//    _headCollectionView.backgroundColor = [UIColor whiteColor];
    
    [_headView addSubview:_headCollectionView];
    

    
//    上下移动按钮
    
    _upDownButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _upDownButton.frame = CGRectMake(0, 0, 50, 40);
    
    _upDownButton.center = CGPointMake(kScreenWith / 2 + 5, 120);
    
//    按钮图片
    [_upDownButton setImage:[UIImage imageNamed:@"down_home@2x.png"] forState:UIControlStateNormal];
    [_upDownButton setImage:[UIImage imageNamed:@"up_home@2x.png"] forState:UIControlStateSelected];
    _upDownButton.selected = YES;
    
//    按钮点击事件
    [_upDownButton addTarget:self
                     action:@selector(upDownAction:)
           forControlEvents:UIControlEventTouchUpInside];
    
    [_headView addSubview:_upDownButton];

    
//    灯
    UIImage *lightImage = [UIImage imageNamed:@"light"];
    _leftLight = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWith / 2 - 30 - 30, 0, 30, 120)];
    _leftLight.image = lightImage;
    [_headView addSubview:_leftLight];
    

    _rightLight = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWith / 2 + 30 , 0, 30, 120)];
    _rightLight.image = lightImage;
    [_headView addSubview:_rightLight];
    
}

#pragma mark - upDownAction
// 头部视图按钮 上下事件
- (void)upDownAction:(UIButton *)button
{
    button.selected = !button.selected;
    if (button.selected)
    {
        [self headViewMoveUp];
    }
    else
    {
        [self headViewMoveDown];
    }
}


#pragma mark - 头部视图上下移动
- (void)headViewMoveUp
{
    [UIView animateWithDuration:0.3 animations:^{
        _headView.top = -45;
        _leftLight.hidden = YES;
        _rightLight.hidden = YES;
        _markView.hidden = YES;
        _upDownButton.selected = YES;
    }];
}

- (void)headViewMoveDown
{
    [UIView animateWithDuration:0.3 animations:^{
        _headView.top = 64;
        _rightLight.hidden = NO;
        _leftLight.hidden = NO;
        _markView.hidden = NO;
        
    }];
}




@end
