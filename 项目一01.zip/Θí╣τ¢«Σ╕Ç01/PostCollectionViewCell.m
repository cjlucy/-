//
//  PostCollectionViewCell.m
//  项目一01
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "PostCollectionViewCell.h"

@implementation PostCollectionViewCell

- (void)awakeFromNib
{
   
    
}

- (void)setMovie:(Movie *)movie
{
    _movie = movie;
    
    _detalView.hidden = YES;
//    电影图片
    NSURL *url = [NSURL URLWithString:_movie.images[@"large"]];
    [_postImage sd_setImageWithURL:url];
    
    
    [_fImageView sd_setImageWithURL:url];
    
//    拉伸图片
    _fImageView.contentMode = UIViewContentModeScaleAspectFill;

    
    
//    中文名
    _cnName.text = [NSString stringWithFormat:@"中文名：%@",_movie.titleCN];
    
//    英文名
    _enName.text = [NSString stringWithFormat:@"英文名：%@",_movie.titleEN];
    
//    上映年份
    _yearLabel.text = [NSString stringWithFormat:@"上映年份：%@",_movie.year];    
//    
    [_star setRating:_movie.reating];
    
}



//翻转
- (void)flipCell
{

    [UIView transitionWithView:self
                      duration:0.3
                       options:UIViewAnimationOptionTransitionFlipFromLeft
                    animations:^{
                        _detalView.hidden = !_detalView.hidden;
                    }
                    completion:nil];
}


@end
