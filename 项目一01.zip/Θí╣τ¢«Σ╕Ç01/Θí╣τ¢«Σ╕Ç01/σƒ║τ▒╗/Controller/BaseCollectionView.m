//
//  BaseCollectionView.m
//  项目一01
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "BaseCollectionView.h"

@implementation BaseCollectionView

- (instancetype)initWithFrame:(CGRect)frame itemSize:(CGSize)itemSize
{
    
    [self _loadDatas];
//    创建布局对象
    UICollectionViewFlowLayout *fayot = [[UICollectionViewFlowLayout alloc] init];
//    单元格大小
    _itemSize = itemSize;
    fayot.itemSize = _itemSize;
    
//    单元格间隙
    fayot.minimumInteritemSpacing = 10;
    fayot.minimumLineSpacing = 10;
    CGFloat leftWidth = (frame.size.width - itemSize.width) / 2;
    fayot.sectionInset = UIEdgeInsetsMake(10, leftWidth, 10, leftWidth);
    
//    滑动方向
    fayot.scrollDirection = UICollectionViewScrollDirectionHorizontal;
//    初始化视图
    self = [super initWithFrame:frame collectionViewLayout:fayot];
    
    if (self)
    {
        self.dataSource = self;
        self.delegate = self;
        
        //        分页显示
        //       self.pagingEnabled = YES;
        
        
        //        注册单元格
        UINib *nib = [UINib nibWithNibName:@"PostCollectionViewCell" bundle:[NSBundle mainBundle]];
        [self registerNib:nib forCellWithReuseIdentifier:@"postCell"];
//        当前页码初始化
        _currentIndex = 0;
    }
    return self;
}

- (void)_loadDatas
{
    //    1.读取文件路径
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"us_box" ofType:@"json"];
    //    2.读取文件
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    //    3.解析文件
    NSError *error = [[NSError alloc] init];
    
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data
                                                        options:NSJSONReadingMutableLeaves
                                                          error:&error];
    
    
    _movieDatas = [[NSMutableArray alloc] init];
    
    for (NSDictionary *d in dic[@"subjects"])
    {
        Movie *movie = [[Movie alloc] initWithDictionary:d];
        
        [_movieDatas addObject:movie];
        
    }
    
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _movieDatas.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return nil;
}


/**
 *  滑动视图停止滑动时调用的方法
 *
 *  @param scrollView          滑动视图
 *  @param velocity            滑动速度
 *  @param targetContentOffset 结构体指针 表示滑动停止之后，滑动视图的偏移量
 */
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
//    NSLog(@"x:%f, y:%f",velocity.x,velocity.y);
//
////    使用结构体指针访问结构体的成员变量，要使用箭头
//    NSLog(@"%f  %f",targetContentOffset->x,targetContentOffset->y);    
    
//    分页显示
//    本质是，滑动停止后，停止在某一页上
    
//    获取系统的滑动结束后的偏移量
    CGFloat offset = targetContentOffset->x;
    
//    计算滑动完成之后，落在哪一个单元格内
//    0 － 0.5 ＋ 间隙宽度
    
    offset += scrollView.width * 0.65 / 2;
    
    NSInteger index = offset / (scrollView.width * 0.65 + 10);
    
//    计算分页后的偏移量
    offset = index * (scrollView.width * 0.65 + 10);
    
//    改变滑动结束后的偏移量
    targetContentOffset->x = offset;
    
//    纪录当前的页码索引
    self.currentIndex = index;
    
    
}





@end
