//
//  NewsCell.h
//  项目一01
//
//  Created by apple on 15/8/5.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "News.h"

@interface NewsCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;

@property (weak, nonatomic) IBOutlet UIImageView *bigImage;
@property (weak, nonatomic) IBOutlet UIImageView *smolImage;

@property (nonatomic , strong) News *news;


@end
