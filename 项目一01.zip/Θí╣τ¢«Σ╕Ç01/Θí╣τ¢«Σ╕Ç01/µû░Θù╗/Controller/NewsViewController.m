//
//  NewsViewController.m
//  项目一01
//
//  Created by apple on 15/8/3.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "NewsViewController.h"
#import "NewsCell.h"

@interface NewsViewController ()

{
    NSMutableArray *_newsData;
    UIImageView *_topImageView;
}

@end

@implementation NewsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = @"新闻";
//    将返回时的文字改为 白色
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    _newsTabView.dataSource = self;
    _newsTabView.delegate = self;
    
    [self _loadData];
    
    
}

- (void)_loadData
{
    NSString *filepath = [[NSBundle mainBundle] pathForResource:@"news_list" ofType:@"json"];
        //    2.读取文件
    NSData *data = [NSData dataWithContentsOfFile:filepath];
    //    3.解析文件
    NSError *error = [[NSError alloc] init];
    NSArray *array = [NSJSONSerialization JSONObjectWithData:data
     options:NSJSONReadingMutableLeaves
       error:&error];
    
    _newsData = [[NSMutableArray alloc] init];
    
    
    for (NSDictionary *dic in array)
    {
        News *news = [[News alloc] initContentWithDic:dic];
        [_newsData addObject:news];
    }
    
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _newsData.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    如果表视图是在故事版中创建的，系统会自动查找；
    if (indexPath.row == 0)
    {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"headCell"];
        
        _topImageView = (UIImageView *)[cell.contentView viewWithTag:100];
//        _topImageView.frame = cell.frame;
        _topImageView.frame = CGRectMake(0, 0, self.view.bounds.size.width, cell.bounds.size.height);
        UILabel *label = (UILabel *)[cell.contentView viewWithTag:101];
        News *news = _newsData[0];
        [_topImageView sd_setImageWithURL:[NSURL URLWithString:news.image]];
//        拉伸图片
        _topImageView.contentMode = UIViewContentModeScaleToFill;
        label.text = news.title;
        label.textColor = [UIColor whiteColor];
        
        
        return cell;
    }
    else
    {
        NewsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"newsCell"];
        cell.news = _newsData[indexPath.row];

        
        return cell;
    }
    
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0)
    {
        return  150;
    }
    else
    {
        return 60;
    }
    
}

//
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat yoffSet = scrollView.contentOffset.y;

    
    if (yoffSet < 0)
    {
        CGFloat scale = (150 - yoffSet) / 150;
        
        CGAffineTransform transform = CGAffineTransformMakeScale(scale, scale);
        _topImageView.transform = transform;
        
        
        _topImageView.center = CGPointMake(kScreenWith / 2, 0);
        
        _topImageView.top = yoffSet;
        
    }
    else
    {
        _topImageView.transform = CGAffineTransformIdentity;
    }
}


//collection
//表视图单元格选中视图
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    News *news = _newsData[indexPath.row];
    NSInteger type = [news.type integerValue];
    if (type == 1)
    {
        UIStoryboard *main = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        
        
        ImageViewController *imageVC = [main instantiateViewControllerWithIdentifier:@"ImageViewController"];
        
        MainTabBarController *mains = (MainTabBarController *)self.tabBarController;

        [mains setTabBarHidden:YES animation:YES];

        
       
        
        [self.navigationController pushViewController:imageVC animated:YES];

        
    }
    else if (type == 0)
    {
        DetaiViewContuoller *detai = [[DetaiViewContuoller alloc] init];
        
        MainTabBarController *mains = (MainTabBarController *)self.tabBarController;
        
        [mains setTabBarHidden:YES animation:YES];
        
        [self.navigationController pushViewController:detai animated:YES];
    }
    
    
    
    
}


















- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
