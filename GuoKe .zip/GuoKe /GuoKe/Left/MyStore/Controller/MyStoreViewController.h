//
//  MyStoreViewController.h
//  GuoKe
//
//  Created by mac on 15/9/25.
//  Copyright (c) 2015年 dzk. All rights reserved.
//

#import "BaseViewController.h"
#import "DetailViewController.h"

#define collectCancal @"qwertyui"

@interface MyStoreViewController : BaseViewController<UITableViewDataSource,UITableViewDelegate>


@end
