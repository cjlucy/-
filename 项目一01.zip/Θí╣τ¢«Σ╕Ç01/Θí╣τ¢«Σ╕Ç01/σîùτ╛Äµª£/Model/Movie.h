//
//  Movie.h
//  项目一01
//
//  Created by apple on 15/8/7.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MovieImageSmallKey @"small"
#define MovieImageLargeKey @"large"
#define MovieImageMediumKey @"medium"


@interface Movie : NSObject

@property(nonatomic,strong) NSString *titleCN; //中午名
@property(nonatomic,strong) NSString *titleEN;// 英文名
@property(nonatomic,strong) NSString *year;//年份
@property(nonatomic,assign) CGFloat reating;//平分
@property(nonatomic,strong) NSDictionary *images;//图片


- (id)initWithDictionary:(NSDictionary *)dic;
@end
