//
//  NewsViewController.h
//  项目一01
//
//  Created by apple on 15/8/3.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "BaseViewController.h"
#import "ImageViewController.h"
#import "NewsCell.h"
#import "DetaiViewContuoller.h"

@interface NewsViewController : BaseViewController<UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *newsTabView;







@end
