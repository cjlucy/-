//
//  MessageCell.m
//  项目一01
//
//  Created by apple on 15/8/8.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "MessageCell.h"

@implementation MessageCell

- (void)awakeFromNib {
    // Initialization code
}



- (void)setMessagedata:(messageData *)messagedata
{
    _messagedata = messagedata;
    
    [_movieImage sd_setImageWithURL:[NSURL URLWithString:
                                    _messagedata.userImage]] ;
    _movieImage.contentMode = UIViewContentModeScaleAspectFill;
    
    _userTitle.text = _messagedata.nickname;
    
    _contenTitle.text = _messagedata.content;
    _contenTitle.numberOfLines = 0;
    
    if (_messagedata.rating == nil || _messagedata.rating.length == 0)
    {
         _mark.text = @"0.0";
    }
    else
    {
        _mark.text = _messagedata.rating;
    }
   
    
    
}






- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
