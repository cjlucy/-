//
//  CinemaCell.h
//  项目一01
//
//  Created by apple on 15/8/12.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Cinema.h"

@interface CinemaCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *cinemaName;

@property (weak, nonatomic) IBOutlet UILabel *address;

@property (weak, nonatomic) IBOutlet UIImageView *seatImage;

@property (weak, nonatomic) IBOutlet UIImageView *couponImage;

@property (weak, nonatomic) IBOutlet UILabel *rating;

@property (weak, nonatomic) IBOutlet UILabel *price;

@property (weak, nonatomic) IBOutlet UILabel *distance;

@property (weak, nonatomic) IBOutlet UIImageView *groupImage;




@property (nonatomic , strong) Cinema *cinema;


@end
