//
//  DetaiViewContuoller.m
//  项目一01
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "DetaiViewContuoller.h"

@interface DetaiViewContuoller ()
{
    UIWebView *_web;
}
@end

@implementation DetaiViewContuoller

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.title = @"新闻页面";
    _web = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, kScreenWith, kScreenHeight + 49)
            ];
    
    [self.view addSubview:_web];
/*
//    通过一个网络地址来加载webView
//    将 http://www.baidu.com 显示到webView上
    
    NSURLRequest *request = [[NSURLRequest alloc]  initWithURL:[NSURL URLWithString:@""]];
//    使用这个网络请求，来加载 web 页面
    [_web loadRequest:request];
    
 */
    
//    读取news.html
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"news" ofType:@"html"];
    
//    将文件内容软化为字符串
    NSString *string = [NSString stringWithContentsOfFile:filePath
                                                 encoding:NSUTF8StringEncoding error:nil];
    
//  读取 news_detail.json
    filePath = [[NSBundle mainBundle] pathForResource:@"news_detail" ofType:@"json"];
    
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    
    
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data
                                                        options:NSJSONReadingMutableLeaves
                                                          error:nil];
    
//
    NSString *title = dic[@"title"];
    NSString *content = dic[@"content"];
    NSString *source = dic[@"source"];
    NSString *time = dic[@"time"];
    
    NSString *htmlString = [NSString stringWithFormat:string,title,content,source,time];
    
    [_web loadHTMLString:htmlString baseURL:nil];
    
    _web.scalesPageToFit = YES;
    
}








- (void)viewWillDisappear:(BOOL)animated
{
    MainTabBarController *main = (MainTabBarController *)self.tabBarController;
    
    [main setTabBarHidden:NO animation:YES];
    
}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
