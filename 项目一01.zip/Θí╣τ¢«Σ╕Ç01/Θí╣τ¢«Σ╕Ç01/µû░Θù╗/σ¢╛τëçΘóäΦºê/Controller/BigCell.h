//
//  BigCell.h
//  项目一01
//
//  Created by apple on 15/8/8.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BigCell : UICollectionViewCell<UICollectionViewDelegate>
{
    NSTimer *_timer;
}

@property (nonatomic , strong) UIImageView *imageView;


- (void)setImageURl:(NSURL *)url;

- (void)backView;

@end
