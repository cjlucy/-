//
//  TopCell.m
//  项目一01
//
//  Created by apple on 15/8/6.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "TopCell.h"

@implementation TopCell

- (void)setTopdata:(topData *)topdata
{
    _topdata = topdata;
    
//    评分
    _markLabel.text = [NSString stringWithFormat:@"%.1f",_topdata.average];
    
//    影名
    _titleLabel.text = _topdata.title;
    
//    电影图片
    NSURL *url = [NSURL URLWithString:_topdata.image[@"small"]];

    [_topImageView sd_setImageWithURL:url];
    
//     评分视图
    [_topStartView setRating:_topdata.average];
    
    
}




@end
