//
//  TopMessage.m
//  项目一01
//
//  Created by apple on 15/8/7.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import "TopMessage.h"

@interface TopMessage ()
{
    UITableView *_tabview;
    NSDictionary *_movieDetail;
    NSMutableArray *_movieComment;
}



@end

@implementation TopMessage

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self _loadData];
    [self _createViews];
    
    self.title = @"电影详情";
    self.view.backgroundColor = [UIColor blueColor];
    
    
    
}


- (void)_loadData
{
//   readyMovie.json
    NSString *filepath = [[NSBundle mainBundle] pathForResource:@"movie_detail" ofType:@"json"];
    //    2.读取文件
    NSData *data = [NSData dataWithContentsOfFile:filepath];
    //    3.解析文件
    NSError *error = [[NSError alloc] init];
    _movieDetail = [NSJSONSerialization JSONObjectWithData:data
                   options:NSJSONReadingMutableLeaves
                     error:&error];

    
//  movie_comment.json
    NSString *filepath1 = [[NSBundle mainBundle] pathForResource:@"movie_comment" ofType:@"json"];
    //    2.读取文件
    NSData *data1 = [NSData dataWithContentsOfFile:filepath1];
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data1
                                                   options:NSJSONReadingMutableLeaves
                                                   error:&error];
    
    _movieComment = [[NSMutableArray alloc] init];
    for (NSDictionary *d in dic[@"list"])
    {
        messageData *datas = [[messageData alloc] initWitdDictionary:d];
       [ _movieComment addObject:datas];
    }

    
}

// 创建tableview
- (void)_createViews
{
   _tabview = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    _tabview.backgroundColor = [UIColor blackColor];

    [self.view addSubview:_tabview];
    
    
    _tabview.dataSource = self;
    _tabview.delegate = self;
    
}

#pragma mark - 数据源方法

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _movieComment.count + 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    头部信息
    if (indexPath.row == 0)
    {
        
        UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
        cell.backgroundColor = [UIColor clearColor];
        _tabview.rowHeight = 240;
//         电影图片   
        UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(0, 5, 100, 120)];
            
        [iv sd_setImageWithURL:[NSURL URLWithString:
                                    _movieDetail[@"image"]]];
        [cell addSubview:iv];
        
//        电影名
        UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(110, 10, 300, 20)];
        nameLabel.text = _movieDetail[@"titleCn"];
        nameLabel.textColor = [UIColor orangeColor];
        nameLabel.font = [UIFont boldSystemFontOfSize:20];
        [cell addSubview:nameLabel];
        
        
//        导演
        UILabel *directors = [[UILabel alloc] initWithFrame:CGRectMake(110, 40, 300, 20)];
        NSArray *array = _movieDetail[@"directors"];
        directors.text = [NSString stringWithFormat:@"导演：%@",[array componentsJoinedByString:@","]];
        directors.textColor = [UIColor whiteColor];
        directors.font = [UIFont systemFontOfSize:15];
        [cell addSubview:directors];
        
//        主演
        UILabel *actors = [[UILabel alloc] initWithFrame:CGRectMake(110, 60, 300, 20)];
        array = _movieDetail[@"actors"];
        actors.text = [NSString stringWithFormat:@"主演：%@",[array componentsJoinedByString:@","]];
        actors.textColor = [UIColor whiteColor];
        actors.font = [UIFont systemFontOfSize:15];
        [cell addSubview:actors];
        
//        类型
        UILabel *type = [[UILabel alloc] initWithFrame:CGRectMake(110, 80, 300, 20)];
        array = _movieDetail[@"type"];
        type.text = [NSString stringWithFormat:@"类型：%@",[array componentsJoinedByString:@","]];
        type.textColor = [UIColor whiteColor];
        type.font = [UIFont systemFontOfSize:15];
        [cell addSubview:type];
        
//        地区，时间
        UILabel *location = [[UILabel alloc] initWithFrame:CGRectMake(110, 100, 300, 20)];
        NSDictionary *d = _movieDetail[@"release"];
        
        location.text = [NSString stringWithFormat:@"%@ : %@",d[@"location"],d[@"date"]];
        location.textColor = [UIColor whiteColor];
        location.font = [UIFont systemFontOfSize:15];
        [cell addSubview:location];
        
        
//        创建UIScrollView
        UIScrollView *scrol = [[UIScrollView alloc] initWithFrame:CGRectMake(10, 145, self.view.bounds.size.width - 20, 75)];

        [cell addSubview:scrol];
        
        CGFloat imageWidth = scrol.height - 6;
        NSArray *a = _movieDetail[@"images"];


        for (int i = 0 ; i < a.count; i ++)
        {
        
            UIImageView *images = [[UIImageView alloc] initWithFrame:CGRectMake(3 + (imageWidth + 3) * i, 3, imageWidth, imageWidth)];
            
            [images sd_setImageWithURL:[NSURL URLWithString:a[i]]];
            
            // 设置图片的拉伸模式
            images.contentMode = UIViewContentModeScaleAspectFill;
            
            [scrol addSubview:images];
            
//            设置图片边框
            images.layer.borderColor = [[UIColor yellowColor] CGColor];
            images.layer.borderWidth = 2;
            images.layer.cornerRadius = 20;
            
            images.layer.masksToBounds = YES;

            
        }
//      3. 设置滑动尺寸
        scrol.contentSize = CGSizeMake(6 * 70 , 70);
        
        
        
        return cell;
    }
    
//   评论视图
    else
    {
        MessageCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        if (cell == nil)
           {
               NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"MessageCell"
                          owner:nil
                        options:nil];
               
               cell = [array lastObject];
        
               cell.backgroundColor = [UIColor clearColor];


           }

        cell.backgroundColor = [UIColor whiteColor];
        cell.messagedata = _movieComment[indexPath.row - 1];
        
//        设置单元格选中样式
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

    
        
        return cell;
    }
}

//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0)
    {
        return 240;
    }
    else
    {
        NSLog(@"indexPath = %li _indexPath = %li ",indexPath.row,_indexPath.row);

        
        if (indexPath.row == _indexPath.row )
        {
           messageData *data = _movieComment[indexPath.row - 1];
            NSString *content = data.content;
            
//            设置计算的选项
            CGSize maxSize = CGSizeMake(290, MAXFLOAT);
            
            NSDictionary *dic = @{NSFontAttributeName:[UIFont systemFontOfSize:17] };
            CGSize titleSize = [content boundingRectWithSize:maxSize
                                                options:NSStringDrawingUsesLineFragmentOrigin
                                             attributes:dic
                                                context:nil].size;
            

            
            CGFloat cellHeight = titleSize.height;
            



            if (cellHeight < 20)
            {
                return 60;
            }
            else
            {
                return cellHeight + 60;
            }
            
        }
        
        return 60;
    }
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    _indexPath = indexPath ;
    
    [_tabview reloadRowsAtIndexPaths:@[_indexPath] withRowAnimation:UITableViewRowAnimationFade];
}







- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   
}



@end
