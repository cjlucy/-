//
//  MainTabBarController.h
//  项目一01
//
//  Created by apple on 15/8/3.
//  Copyright (c) 2015年 😄😄😄👌. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TabBarButton.h"

@interface MainTabBarController : UITabBarController

/**
 *  设置自定义的标签栏是否隐藏
 *
 *  @param hidden    是否隐藏
 *  @param animation 是否添加动画
 */
- (void)setTabBarHidden:(BOOL)hidden animation:(BOOL)animation;

@end
